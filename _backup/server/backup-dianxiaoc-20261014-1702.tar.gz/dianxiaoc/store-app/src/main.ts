import { createApp } from 'vue'
import { createPinia } from 'pinia'
import App from './App.vue'
import router from './router'

import './styles/tokens.css'
import './styles/global.css'
import './styles/motion.css'

const app = createApp(App)

app.use(createPinia())
app.use(router)

app.mount('#app')
